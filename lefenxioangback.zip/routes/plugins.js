const express = require('express');
const { readData, writeData } = require('../utils/fileDb');
const router = express.Router();

// ================= 1. 获取所有公开插件列表 =================
router.get('/', async (req, res) => {
    try {
        const plugins = await readData('plugins.json');

        // 1. 按发布时间倒序排列
        const sortedPlugins = plugins.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        // 🔥 2. 核心调整：数据裁剪，只返回列表页需要的精简信息
        const listData = sortedPlugins.map(p => ({
            name: p.name,
            version: p.version,
            author: p.author,
            desc: p.desc,
            // 💡 建议：列表卡片通常也需要展示图标和标签，所以我帮你保留了这两个。
            // 如果你的 UI 真的极简到连图标都不要，可以直接把下面两行删掉。
            icon: p.icon || '',
            tags: p.tags || []
        }));

        res.json({ code: 200, msg: "success", data: listData });
    } catch (error) {
        console.error('[Error] 获取精简插件列表失败:', error);
        res.status(500).json({ code: 500, msg: "获取插件列表失败", data: [] });
    }
});

// ================= 2. 获取单个插件详情 & 统计浏览量 =================
// 实际请求路径: GET /api/v1/plugins/:name
router.get('/:name', async (req, res) => {
    try {
        const { name } = req.params;
        const plugins = await readData('plugins.json');
        const pluginIndex = plugins.findIndex(p => p.name === name);

        if (pluginIndex === -1) {
            return res.status(404).json({ code: 404, msg: "未找到该插件" });
        }

        // 🔥 核心逻辑：浏览量 +1
        // 如果原数据里没有 views 字段，(plugins[pluginIndex].views || 0) 会将其初始化为 0
        plugins[pluginIndex].views = (plugins[pluginIndex].views || 0) + 1;

        // 异步将更新后的数据写回 JSON 和内存缓存
        // 注意：这里故意不加 await！让硬盘慢慢去写，我们立刻把数据返回给前端，保证接口极速响应
        writeData('plugins.json', plugins).catch(err => console.error('[Error] 更新浏览量失败:', err));

        res.json({ code: 200, msg: "success", data: plugins[pluginIndex] });
    } catch (error) {
        res.status(500).json({ code: 500, msg: "获取插件详情失败" });
    }
});

// ================= 3. 专属下载通道 & 统计下载量 =================
// 实际请求路径: GET /api/v1/plugins/:name/download
router.get('/:name/download', async (req, res) => {
    try {
        const { name } = req.params;
        const plugins = await readData('plugins.json');
        const pluginIndex = plugins.findIndex(p => p.name === name);

        if (pluginIndex === -1) {
            return res.status(404).json({ code: 404, msg: "未找到该插件" });
        }

        const plugin = plugins[pluginIndex];

        if (!plugin.downloadUrl) {
            return res.status(400).json({ code: 400, msg: "该插件作者暂未提供下载链接" });
        }

        // 🔥 核心逻辑：下载量 +1
        plugins[pluginIndex].downloads = (plugins[pluginIndex].downloads || 0) + 1;

        // 同样不加 await，异步写回硬盘
        writeData('plugins.json', plugins).catch(err => console.error('[Error] 更新下载量失败:', err));

        // 🔥 魔法时刻：HTTP 302 重定向
        // 后端不直接传输文件流，而是告诉浏览器：“你要的文件不在这里，请跳转到这个 GitHub 链接去下”
        res.redirect(302, plugin.downloadUrl);

    } catch (error) {
        console.error('[Error] 处理下载请求失败:', error);
        res.status(500).json({ code: 500, msg: "服务器内部错误，无法处理下载" });
    }
});

module.exports = router;